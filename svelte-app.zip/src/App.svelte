<script>
	// import Speedometer from "svelte-speedometer"
	let name = 'world';
</script>

<h1>Hello {name}!</h1>